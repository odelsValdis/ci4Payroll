<?= $this->extend('layout/_layout') ?>

<?= $this->section('content') ?>
<style>
    .dx-data-row td.number {  
    text-align: right!important;  
}  
</style>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header bg-secondary text-white">
            Pengisian Data Rekap Dana Bantuan Operasional Sekolah 
			</div>
			<div class="card-body">
            
                <div id="formInput"></div>
                <div id="tabPanel"></div>

            </div>
            
        </div>

    </div>
</dv>
<div class="row">
    <div class="col-md-12">
        <div class="card">
        <div class="card-header bg-secondary text-white">
        <?php echo $title ?>
        </div>
        <div class="card-body">
        <div id="gridContainer"></div>
        </div>    
    </div>
    </div>
</div>
<div id="popup"></div>
<script>
var SchoolID;
var DataKotaSource = {
    store: new DevExpress.data.CustomStore({
        key: "id",
        loadMode: "raw",
        load: function() {
            // Returns an array of objects that have the following structure:
            // { id: 1, name: "John Doe" }
            return $.getJSON("<?php echo base_url('api/kota')?>");
        }
    }),
    sort: "branchName"
}

var dataSekolahSource = {
    store: new DevExpress.data.CustomStore({
        key: "id",
        loadMode: "raw",
        load: function() {
            // Returns an array of objects that have the following structure:
            // { id: 1, name: "John Doe" }
            return $.getJSON("<?php echo base_url('api/sekolah')."/".$branchId?>");
        }
    }),
    sort: "branchName"
}

var dataRekValueSource = {
    store: new DevExpress.data.CustomStore({
        key: "id",
        loadMode: "raw",
        load: function() {
            // Returns an array of objects that have the following structure:
            // { id: 1, name: "John Doe" }
            return $.getJSON("<?php echo base_url('api/mylibs/getMsValue')."/".$idValue?>");
        }
    }),
    sort: "name"
}

var datasignaturePemeriksaSource = {
    store: new DevExpress.data.CustomStore({
        key: "id",
        loadMode: "raw",
        load: function() {
            // Returns an array of objects that have the following structure:
            // { id: 1, name: "John Doe" }
            return $.getJSON("<?php echo base_url('api/mylibs/getSignaturePemeriksa/2')?>");
        }
    }),
    sort: "nama"
}


var datasignaturePemeriksaKeuanganSource = {
    store: new DevExpress.data.CustomStore({
        key: "id",
        loadMode: "raw",
        load: function() {
            // Returns an array of objects that have the following structure:
            // { id: 1, name: "John Doe" }
            return $.getJSON("<?php echo base_url('api/mylibs/getSignaturePemeriksa/1')?>");
        }
    }),
    sort: "nama"
}

var SignatureStore = {
    store: new DevExpress.data.CustomStore({
        key: "id",
        loadMode: "raw",
       
        load: function() {
            // Returns an array of objects that have the following structure:
            // { id: 1, name: "John Doe" }
            return $.getJSON("<?php echo base_url('api/mylibs/getSignaturesekolah/3')."/".$branchId?>");
        }
    }),
    sort: "nama"
}

var BendaharaStore = {
    store: new DevExpress.data.CustomStore({
        key: "id",
        loadMode: "raw",
       
        load: function() {
            // Returns an array of objects that have the following structure:
            // { id: 1, name: "John Doe" }
            return $.getJSON("<?php echo base_url('api/mylibs/getSignaturesekolah/4')."/".$branchId?>");
        }
    }),
    sort: "nama"
}
var SchoolID;
var trreport = { "id": "0",
        "idBranch": "<?php echo $branchId ?>",
        "year": "2021",
        "idRek": "4",
        "idValue": "<?php echo $idValue ?>",
        "amount": "0",
        "amount2": "0",
        "amount3": "0",
        "amount4": "0",
        "dataLock": "0",
        "fileNameUpload": "-",
        "statusWTP": "0",
        "userId": "<?= session()->get('userId') ?>",
        "userIdUpdate": "",
        "signatureAdminSchoolId": "<?php echo $signatureAdminSchoolId ?>",
        "signatureAdminId": "<?php echo $signatureAdminId ?>",
        "signatureSchoolHeadId": "<?php echo $signatureSchoolHeadId ?>",
        "signatureSchoolId": "<?php echo $signatureSchoolId ?>"};

   $(function() {
    $("#formInput").dxForm({
        formData: trreport,
        colCount:6,
        items: [
            {
                colSpan:2,
                    dataField: "idBranch",
                    label:{text: "Nama Sekolah",}, 
                    editorType: "dxSelectBox",
                    editorOptions: { 
                        dataSource: dataSekolahSource,
                         displayExpr: "branchName",
                         valueExpr: "id",
                        searchEnabled: true,
                        readOnly:true
                    },
                    validationRules: [{
                        type: "required",
                        message: "Nama Sekolah Harus Di Isi"
                    }],
                   
                },
                {
                    colSpan:2,
                    dataField: "idValue",
                    label:{text: "Jenis Dokumen",}, 
                    editorType: "dxSelectBox",
                    editorOptions: {
                      
                        dataSource: dataRekValueSource,
                         displayExpr: "name",
                         valueExpr: "id",
                        searchEnabled: true,
                        readOnly:true
                    },
                    validationRules: [{
                        type: "required",
                        message: "Jenis Dokumen Harus Di Isi"
                    }]

                },
                {
                    dataField: "year",
                    editorType: "dxNumberBox",
                    editorOptions: {
                        min: 2019,
                         max: 2024,
                         
                        showSpinButtons: true,
                        readOnly:true
                    }
                },
                { 
                    itemType:"empty",

                },
                 {
                itemType: "group",
                 caption: "Penanda tangan Sekolah",
                 labelLocation:"top",
                 colSpan:2,
                    items:[
                        {
                            dataField: "signatureSchoolHeadId",
                            label:{text: "Kepala Sekolah",}, 
                            editorType: "dxSelectBox",
                            editorOptions: { 
                                dataSource:  SignatureStore,
                              
                                displayExpr: "nama",
                                valueExpr: "id",
                                searchEnabled: true,
                                onValueChanged: function (data) {
                                     updateSignature(data.value,"signatureSchoolHeadId");
                                 }
                                },
                                validationRules: [{
                                type: "required",
                                message: "Kepala Sekolah Harus Di Isi"
                                }]
                        },
                        {
                            dataField: "signatureSchoolId",
                            label:{text: "Bendahara",}, 
                            editorType: "dxSelectBox",
                            editorOptions: { 
                                dataSource:  BendaharaStore,
                              
                                displayExpr: "nama",
                                valueExpr: "id",
                                searchEnabled: true,
                                onValueChanged: function (data) {
                                     updateSignature(data.value,"signatureSchoolId");
                                 }
                                },
                                validationRules: [{
                                type: "required",
                                message: "Bendahara Harus Di Isi"
                                }]
                        },
                    ]
                },
                {
                  itemType: "group",
                 caption: "Penanda tangan Pemeriksa",
                 labelLocation:"top",
                 colSpan:2,
                    items: [{
                            dataField: "signatureAdminSchoolId",
                            label:{text: "Dinas Pendidikan",}, 
                            editorType: "dxSelectBox",
                            editorOptions: { 
                                dataSource: datasignaturePemeriksaSource,
                                displayExpr: "nama",
                                valueExpr: "id",
                                searchEnabled: true,
                                onValueChanged: function (data) {
                                     updateSignature(data.value,"signatureAdminSchoolId");
                                 }
                                
                                },
                                validationRules: [{
                                type: "required",
                                message: "Pemeriksa Harus Di Isi"
                                }]
                            },
                            {
                            dataField: "signatureAdminId",
                            label:{text: "Biro Keuangan",}, 
                            editorType: "dxSelectBox",
                            editorOptions: { 
                                dataSource: datasignaturePemeriksaKeuanganSource,
                                displayExpr: "nama",
                                valueExpr: "id",
                                searchEnabled: true,
                                onValueChanged: function (data) {
                                     updateSignature(data.value,"signatureAdminId");
                                 }
                                },
                                validationRules: [{
                                type: "required",
                                message: "Pemeriksa Harus Di Isi"
                                }]
                            },

                           ]
                        }, 
                    ]
                },
               
                
                );
});

var SERVICE_URL  = '<?php echo base_url('api/bos')?>';


//var URL = "<?php echo base_url('api/bos')?>";

    var bosStore = new DevExpress.data.CustomStore({
        key: "id",
        load: function() {
            return $.getJSON(SERVICE_URL+"/getTrreport/"+<?php echo $param ?>);
           // return sendRequest(URL + "/getTrreport/"+$param);
        },
        insert: function(values) {
            return sendRequest(SERVICE_URL + "/InsertOrder", "POST", {
                values: JSON.stringify(values)
            });
        },
        update: function(key, values) {
            return $.ajax({
             url: SERVICE_URL + "/updateTrreport/"+<?php echo $param ?>,
             method: "POST",
             data: values,
         });
            
        },
        remove: function(key) {
            return sendRequest(SERVICE_URL + "/DeleteOrder", "DELETE", {
                key: key
            });
        }
    });





$(function(){
    $("#gridContainer").dxDataGrid({
        dataSource:bosStore,
        // "<?php echo base_url('api/bos')?>"+"/GetBos/"+<?php echo $tipeRek?>+"/"+<?php echo $branchId ?>+"/"+<?php echo $idValue ?>+"/"+<?php echo $idYear?>,
        editing: {
            mode: "batch",
            allowUpdating: true,
            selectTextOnEditStart:true,

        },
    //    remoteOperations: true,
        repaintChangesOnly: true,
        onRowUpdating: function(options) {  
                options.newData = $.extend({}, options.oldData, options.newData);  
        }  ,
        showRowLines:true,

        sorting: {
            mode: "none"
        },
        onCellPrepared: function(e) {
            if(e.rowType === "data"){
                
                if( e.column.dataField === "name") {
                e.cellElement.css("color", e.data.color);
                }

                if(e.data.id===901||e.data.id===902||e.data.id===903||e.data.id===904){
                    e.cellElement.css("background-color","#dadada");
                    e.cellElement.css('font-weight', 'bold');
                }

                // if(e.data.id===901||e.data.id===902||e.data.id===903||e.data.id===904){
                //     if(e.column.dataField === "amount"||e.column.dataField === "amount2"||e.column.dataField === "amount3"){
                //         e.cellElement.readOnly(true);
                //     }
                // }
                // Tracks the `Amount` data field
               
            }
        },
        onEditorPreparing: function(e) {
            if(e.parentType === "dataRow" && e.dataField === "amount" &&( e.row.data.id===901||e.row.data.id===902||e.row.data.id===903||e.row.data.id===904)) {
                e.editorOptions.readOnly = true;
            }
            
        },
        onEditorPrepared(e){
            var result=0;
            if(e.dataField.substring(0, 6)=="amount"){
                var field = e.dataField
                var grid = getGrid();
			     var lastIndex = 7;
                let rows =  grid.getVisibleRows();
                      $(e.editorElement).dxNumberBox("instance").on("valueChanged", function (args) {
                        if(e.row.data.id==="250"||e.row.data.id==="258"||e.row.data.id==="410"||e.row.data.id==="420"){
                     
                            for (r = 0; r <= lastIndex; r++) {
                                
                                let row = rows[r];
                                let idRow = row.data["id"];
                                if(idRow==="250"||idRow==="258"||idRow==="410"||idRow==="420"){
                                    result += parseInt(row.data[field]);
                                }
                            
                            }
                            result +=parseInt(args.value);
                            grid.cellValue(8, field, result);
                            result=0;
                         }
                         if(e.row.data.id==="3"||e.row.data.id==="4"){
                                
                                for (r = 0; r <= lastIndex; r++) {
                                    
                                    let row = rows[r];
                                    let idRow = row.data["id"];
                                    if(idRow==="3"){
                                        result += parseInt(row.data[field]);
                                    }
                                    if(idRow==="4"){
                                        result -= parseInt(row.data[field]);
                                    }
                                }
                                if(e.row.data.id==="3"){
                                result +=parseInt(args.value);
                                }
                                if(e.row.data.id==="4"){
                                    result -= parseInt(args.value);
                                    
                                }
                                grid.cellValue(9, field, result);
                                result=0;
                            }
                        if(e.row.data.id==="4"||e.row.data.id==="9"||e.row.data.id==="10"){
                     
                            for (r = 0; r <= lastIndex; r++) {
                                
                                let row = rows[r];
                                let idRow = row.data["id"];
                                if(idRow==="4"||idRow==="10"){
                                    result += parseInt(row.data[field]);
                                }
                                if(idRow==="9"){
                                        result -= parseInt(row.data[field]);
                                 }
                                 result=0;
                            
                            }
                          

                            grid.cellValue(10, field, result);
                            result=0;
                        }
                        if(e.row.data.id==="9"||e.row.data.id==="10"||e.row.data.id==="250"||e.row.data.id==="258"||e.row.data.id==="410"||e.row.data.id==="420"){ 
                            for (r = 0; r <= lastIndex; r++) {
                                
                                let row = rows[r];
                                let idRow = row.data["id"];
                                
                                if(idRow==="9"){
                                        result += parseInt(row.data[field]);
                                 }
                                 if(idRow==="10"||idRow==="250"||idRow==="258"||idRow==="410"||idRow==="420"){
                                    result -= parseInt(row.data[field]);
                                 }
                            
                            }
                            if(e.row.data.id==="9"){
                            
                                 result +=parseInt(args.value);
                            }if(e.row.data.id==="10"||e.row.data.id==="250"||e.row.data.id==="258"||e.row.data.id==="410"||e.row.data.id==="420"){ 
                        
                                   result -= parseInt(args.value);
                                    
                             }

                            grid.cellValue(11, field, result);
                            result=0;
                        } 

                    })
                    
                
            }
        },
        onToolbarPreparing : function(e) {
		var dtGrid = e.component;
		e.toolbarOptions.items.unshift(
			
            
           

			{
				location: "before",
				widget: "dxButton",
				options: {
					hint: "Open",
					icon: "arrowleft",
					text: "Batal",
					type:"default",
					 onClick: function (e) {
                        let backUrl = "<?php echo base_url()?>"+"/inputbos";
                        window.location.replace(backUrl);
					
                     }
				}
			},
			




		);
	},
    
        columns: [
                    {
                        dataField:"id",
                        caption:"ID",
                        visible:false
                    },
                    {  
                        caption: 'No',  
                        cellTemplate: function(cellElement, cellInfo) {  
                            cellElement.text(cellInfo.row.rowIndex+1)  
                        } ,
                        width:30, 
                    },
                    {
                        dataField:"name",
                        allowEditing:false,
                        caption:"Uraian",
                        width:250,    
                    },
                    {
                        cssClass: "number",  
                        dataField:"amount",
                        caption:"Realisasi Dana Bos Tahap I (Rp)",
                        dataType:"number",
                        editorOptions:{min:0},
                        // editCellTemplate: numberBoxEditorTemplate,
                        format: {
                                    type: "fixedPoint",
                                    precision: 0
                                },
                    },
                    {
                        cssClass: "number", 
                        dataField:"amount2",
                        caption:"Realisasi Dana Bos Tahap II (Rp)",
                        dataType:"number",
                        editorOptions:{min:0},
                        //editCellTemplate: numberBoxEditorTemplate,
                        format: {
                                    type: "fixedPoint",
                                    precision: 0
                                },
                    },
                    {
                        cssClass: "number", 
                        dataField:"amount3",
                        caption:"Realisasi Dana Bos Tahap III (Rp)",
                       // editCellTemplate: numberBoxEditorTemplate,
                       dataType:"number", 
                       editorOptions:{min:0},
                       format: {
                                    type: "fixedPoint",
                                    precision: 0
                                },
                    },
                    {
                        cssClass: "number", 
                        caption: "Jumlah",
                        dataType:"number", 
                        calculateCellValue: function(rowData) {
                            return  parseInt(rowData.amount) +  parseInt(rowData.amount2)+ parseInt(rowData.amount3);
                        },
                        format: {
                                    type: "fixedPoint",
                                    precision: 0
                                },
                    },

                    {
                        dataField:"signatureSchoolHeadId",
                        caption:"Kepalasekolah",
                        visible:false,
                        
                    },
                    {
                        dataField:"signatureSchoolId",
                        caption:"Bendahara",
                        visible:false,
                    },
                    
                    {
                        dataField:"signatureAdminSchoolId",
                        caption:"dinas",
                        visible:false,
                    },
                    {
                        dataField:"signatureAdminId",
                        caption:"Biro keu",
                        visible:false,
                    },
        ]
    })
})
function getGrid(){
    return $("#gridContainer").dxDataGrid("instance");
}
function numberBoxEditorTemplate(cellElement, cellInfo){
    return $("<div>").dxNumberBox({
        value: cellInfo.value,
        format: "#,##0",
        onValueChanged: function(e) {
                cellInfo.setValue(e.value)
            },
    })
}
function isEntry(idNo){
    return true;
}

function sendBatchRequest(url, changes) {
        var d = $.Deferred();

        $.ajax(url, {
            method: "POST",
            data: JSON.stringify(changes),
            cache: false,
            contentType: "application/json",
            xhrFields: { withCredentials: true }
        }).done(d.resolve).fail(function (xhr) {
            d.reject(xhr.responseJSON ? xhr.responseJSON.Message : xhr.statusText);
        });

        return d.promise();
    }


    function updateSignature(val,datafield){
        var grid = getGrid();
	    var lastIndex = 7;
        for (r = 0; r <= lastIndex; r++) {
            grid.cellValue(r, datafield, val);             
        }
    }

</script>
<?= $this->endSection() ?>